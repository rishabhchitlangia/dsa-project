#ifdef __cplusplus
extern "C" {
#endif
int kbhit();
void kbinit();
void kbfini();
#ifdef __cplusplus
}
#endif
